#!/usr/bin/env bash
# =============================================================================
# zcu104_posedetect_benchmark.sh
#
# Benchmark + profiling harness for Vitis AI PoseDetect (sp_net) on ZCU104.
# Run ON the board (xilinx-zcu104-20222, 192.168.1.10).
#
# Modes:
#   check              Preflight only (files, image list, tools, env snapshot)
#   baseline           N uninstrumented runs at THREADS threads
#   sweep              Uninstrumented runs for each thread count in THREAD_LIST
#   profile            One INSTRUMENTED run under vaitrace (never mix with baseline)
#   all                check + baseline (+ sweep if SWEEP=1) + profile + report
#   report [OUTDIR]    Regenerate results/report from an existing output dir
#                      (also works on legacy dirs from the older script)
#
# Usage:
#   ./zcu104_posedetect_benchmark.sh all
#   RUNS=5 THREADS=2 ./zcu104_posedetect_benchmark.sh baseline
#   ./zcu104_posedetect_benchmark.sh report /tmp/zcu104_posedetect_demo_20240207_091604
#
# Environment overrides (all optional):
#   THREADS=1  DURATION=60  RUNS=3  COOLDOWN=10  WARMUP_SEC=0
#   PROF_SEC=30  THREAD_LIST="1 2 4"  SWEEP=0  SWEEP_RUNS=2
#   MODEL=sp_net  IMAGE_LIST=/tmp/posedetect_images.txt  OUT_BASE=/tmp
#   OUTDIR=<explicit output dir>
#
# The benchmark command syntax is exactly the verified one:
#   test_performance_posedetect <model> -t <threads> -s <sec> -l <log> <imagelist>
# =============================================================================
set -uo pipefail

# ----------------------------- configuration ---------------------------------
VAI_ROOT=${VAI_ROOT:-/home/root/Vitis-AI}
SAMPLE_DIR=${SAMPLE_DIR:-$VAI_ROOT/examples/vai_library/samples/posedetect}
PERF_BIN=${PERF_BIN:-$SAMPLE_DIR/test_performance_posedetect}
VIDEO_BIN=${VIDEO_BIN:-$SAMPLE_DIR/test_video_posedetect}   # presence-checked only
MODEL=${MODEL:-sp_net}
IMAGE_LIST=${IMAGE_LIST:-/tmp/posedetect_images.txt}
EXPECTED_IMAGES=${EXPECTED_IMAGES:-100}
EXPECTED_HOST=${EXPECTED_HOST:-xilinx-zcu104-20222}

THREADS=${THREADS:-1}
DURATION=${DURATION:-60}
RUNS=${RUNS:-3}
COOLDOWN=${COOLDOWN:-10}
WARMUP_SEC=${WARMUP_SEC:-0}
PROF_SEC=${PROF_SEC:-30}
PROF_MARGIN=${PROF_MARGIN:-15}        # vaitrace timeout = PROF_SEC + margin so the app ends first
THREAD_LIST=${THREAD_LIST:-"1 2 4"}
SWEEP=${SWEEP:-0}
SWEEP_RUNS=${SWEEP_RUNS:-2}
TIMEOUT_MARGIN=${TIMEOUT_MARGIN:-60}
MON_INTERVAL=${MON_INTERVAL:-1}
OUT_BASE=${OUT_BASE:-/tmp}
DPU_CU_NAMES=${DPU_CU_NAMES:-"DPUCZDX8G_1 DPUCZDX8G_2"}
DPU_CU_ADDRS=${DPU_CU_ADDRS:-"0x80000000 0x80001000"}

# Historical references (NOT results of this script)
HIST1_FPS=600.214; HIST1_E2E=1664.22; HIST1_DPU=1370.11
HIST2_FPS=596.611; HIST2_E2E=1674.10; HIST2_DPU=1377.57
HIST_VT_FPS=562.981; HIST_VT_E2E=1773.69; HIST_VT_DPU=1432.51

MODE=${1:-help}
LOCKDIR=/tmp/zcu104_posedetect_bench.lock
MON_PID=""
HAVE_LOCK=0
FAILED_RUNS=0

# ------------------------------- utilities -----------------------------------
usage() { sed -n '2,31p' "$0" | sed 's/^# \{0,1\}//'; }
now()   { awk '{print $1}' /proc/uptime; }
ts()    { date '+%H:%M:%S'; }
log()   { local m; m="[$(ts)] $*"; echo "$m"; [ -n "${OUTDIR:-}" ] && [ -d "$OUTDIR" ] && echo "$m" >> "$OUTDIR/run.log"; return 0; }
warn()  { log "WARN: $*"; }
fatal() { log "FATAL: $*"; exit 1; }
is_num(){ [[ "${1:-}" =~ ^[0-9]+(\.[0-9]+)?$ ]]; }

cleanup() {
  stop_monitor
  if [ "$HAVE_LOCK" = 1 ]; then rm -rf "$LOCKDIR"; fi
}
trap cleanup EXIT
trap 'log "Interrupted"; exit 130' INT TERM

acquire_lock() {
  if mkdir "$LOCKDIR" 2>/dev/null; then
    echo $$ > "$LOCKDIR/pid"; HAVE_LOCK=1; return 0
  fi
  local old; old=$(cat "$LOCKDIR/pid" 2>/dev/null || echo "")
  if [ -n "$old" ] && ! kill -0 "$old" 2>/dev/null; then
    rm -rf "$LOCKDIR"; mkdir "$LOCKDIR" && echo $$ > "$LOCKDIR/pid" && HAVE_LOCK=1 && return 0
  fi
  echo "FATAL: another benchmark instance is running (pid ${old:-?}); concurrent runs would corrupt results." >&2
  exit 1
}

# ------------------------- system monitor (background) -----------------------
# CSV columns: epoch,cpu_busy_pct,load1,mem_avail_mb,max_temp_c,cpu_mhz
# cpu_busy_pct is aggregate over all cores (4 cores: one saturated core ~ 25%).
start_monitor() {
  local csv=$1
  echo "epoch,cpu_busy_pct,load1,mem_avail_mb,max_temp_c,cpu_mhz" > "$csv"
  (
    pt=0; pi=0
    while :; do
      read -r _ u n s i w q sq st _ < /proc/stat
      tot=$((u+n+s+i+w+q+sq+st)); idl=$((i+w))
      busy=""
      if [ "$pt" -gt 0 ] && [ $((tot-pt)) -gt 0 ]; then
        busy=$(awk -v t=$((tot-pt)) -v d=$((idl-pi)) 'BEGIN{printf "%.1f",100*(t-d)/t}')
      fi
      pt=$tot; pi=$idl
      read -r l1 _ < /proc/loadavg
      mem=$(awk '/MemAvailable/{printf "%d",$2/1024}' /proc/meminfo)
      temp=$(cat /sys/class/thermal/thermal_zone*/temp /sys/class/hwmon/hwmon*/temp*_input 2>/dev/null \
             | sort -n | tail -n1 | awk 'NF{printf "%.1f",$1/1000}')
      mhz=$(awk '{printf "%d",$1/1000}' /sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq 2>/dev/null)
      echo "$(date +%s),$busy,$l1,$mem,$temp,$mhz" >> "$csv"
      sleep "$MON_INTERVAL"
    done
  ) &
  MON_PID=$!
}
stop_monitor() {
  if [ -n "${MON_PID:-}" ]; then
    kill "$MON_PID" 2>/dev/null; wait "$MON_PID" 2>/dev/null
    MON_PID=""
  fi
  return 0
}

# ------------------- XRT CU usage / interrupt snapshots ----------------------
snapshot_xrt() {   # $1 = output file
  if command -v xbutil >/dev/null 2>&1; then
    { xbutil examine -r dynamic-regions 2>&1 || xbutil query 2>&1; } > "$1"
  else
    echo "xbutil not available" > "$1"
  fi
}
snapshot_irq() { cat /proc/interrupts > "$1" 2>/dev/null || echo "unavailable" > "$1"; }

# Usage counter of a CU: first integer following the CU's hex base address.
cu_usage() {   # $1 = xrt snapshot file, $2 = CU name, $3 = CU address
  awk -v n="$2" -v a="$3" '
    index($0,n) || index(tolower($0),tolower(a)) {
      for (i=1;i<=NF;i++) if ($i ~ /^0x[0-9a-fA-F]+$/ && (i+1)<=NF && $(i+1) ~ /^[0-9]+$/) { print $(i+1); exit }
    }' "$1" 2>/dev/null
}
cu_delta() {   # $1 before, $2 after, $3 name, $4 addr -> delta or NA
  local b a; b=$(cu_usage "$1" "$3" "$4"); a=$(cu_usage "$2" "$3" "$4")
  if is_num "$b" && is_num "$a"; then echo $((a-b)); else echo NA; fi
}
irq_delta_report() {   # $1 before, $2 after -> lines for DPU/XRT-looking IRQs
  awk -v re='dpu|zocl|xrt|ert|80000000|80001000|a0000000' '
    function sum(line,  a,n,i,s){n=split(line,a," ");s=0;for(i=2;i<=n;i++){if(a[i]~/^[0-9]+$/)s+=a[i];else break};return s}
    NR==FNR { if (tolower($0)~re) b[$1]=sum($0); next }
    tolower($0)~re { printf "  %s delta=%d  (%s %s)\n",$1,sum($0)-b[$1],$(NF-1),$NF }' "$1" "$2" 2>/dev/null
}

# ------------------------------ output parsing -------------------------------
# Tries the "KEY=value" style first, then looser patterns. Searches the console
# capture first, then the -l log file.
parse_metric() {   # $1 key (FPS|E2E|DPU), then files...
  local key=$1 f v pat; shift
  case $key in
    FPS) pat='(^|[^A-Za-z_])FPS[[:space:]]*[=:]' ;;
    E2E) pat='E2E_?MEAN[[:space:]]*[=:]' ;;
    DPU) pat='DPU_?MEAN[[:space:]]*[=:]' ;;
  esac
  for f in "$@"; do
    [ -r "$f" ] || continue
    v=$(grep -aiE "$pat" "$f" | tail -n1 | grep -aoE '[0-9]+(\.[0-9]+)?' | tail -n1)
    is_num "$v" && { echo "$v"; return 0; }
  done
  case $key in
    E2E) pat='E2E.*(mean|avg)' ;;
    DPU) pat='DPU.*(mean|avg)' ;;
    FPS) pat='fps' ;;
  esac
  for f in "$@"; do
    [ -r "$f" ] || continue
    v=$(grep -aiE "$pat" "$f" | tail -n1 | grep -aoE '[0-9]+(\.[0-9]+)?' | tail -n1)
    is_num "$v" && { echo "$v"; return 0; }
  done
  echo ""
}

# ------------------------------- preflight -----------------------------------
ensure_image_list() {
  if [ ! -s "$IMAGE_LIST" ]; then
    warn "Image list $IMAGE_LIST missing/empty; regenerating from $VAI_ROOT and /usr/share/vitis-ai-library"
    find "$VAI_ROOT" /usr/share/vitis-ai-library -type f \
      \( -iname '*.jpg' -o -iname '*.jpeg' -o -iname '*.png' \) 2>/dev/null \
      | sort | head -n "$EXPECTED_IMAGES" > "$IMAGE_LIST"
  fi
  local total missing=0 p
  total=$(grep -c . "$IMAGE_LIST")
  [ "$total" -gt 0 ] || fatal "Image list $IMAGE_LIST has no entries"
  while IFS= read -r p; do
    [ -z "$p" ] && continue
    [ -r "$p" ] || { missing=$((missing+1)); warn "Unreadable image: $p"; }
  done < "$IMAGE_LIST"
  [ "$missing" -eq 0 ] || fatal "$missing image path(s) in $IMAGE_LIST are unreadable; benchmark would be invalid"
  [ "$total" -eq "$EXPECTED_IMAGES" ] || warn "Image list has $total entries (expected $EXPECTED_IMAGES)"
  cp "$IMAGE_LIST" "$OUTDIR/posedetect_images.txt"
  if command -v md5sum >/dev/null 2>&1; then md5sum "$IMAGE_LIST" > "$OUTDIR/posedetect_images.md5"; fi
  log "Image list OK: $total entries"
}

capture_env() {
  local f="$OUTDIR/env.txt"
  {
    echo "date:      $(date -Is 2>/dev/null || date)"
    echo "hostname:  $(hostname)"
    echo "uname:     $(uname -a)"
    echo "mode:      $MODE  THREADS=$THREADS DURATION=$DURATION RUNS=$RUNS WARMUP_SEC=$WARMUP_SEC PROF_SEC=$PROF_SEC"
    echo "vai.sh:    ${VAI_SOURCED:-not sourced}"
    echo "bash:      $BASH_VERSION"
    echo "uptime:    $(cat /proc/uptime)"
    echo "loadavg:   $(cat /proc/loadavg)"
    echo "--- cpufreq (cpu0) ---"
    for k in scaling_governor scaling_cur_freq scaling_min_freq scaling_max_freq; do
      printf '%s=%s\n' "$k" "$(cat /sys/devices/system/cpu/cpu0/cpufreq/$k 2>/dev/null || echo NA)"
    done
    echo "--- os-release ---"; cat /etc/os-release 2>/dev/null
    echo "--- xdputil query (DPU arch/frequency) ---"
    if command -v xdputil >/dev/null 2>&1; then
      if command -v timeout >/dev/null 2>&1; then timeout 30 xdputil query 2>&1; else xdputil query 2>&1; fi
    else echo "xdputil not available"; fi
    echo "--- dmesg tail ---"; dmesg 2>/dev/null | tail -n 30
  } > "$f" 2>&1
  snapshot_xrt "$OUTDIR/xrt_dynamic_regions.txt"
}

preflight() {
  log "Preflight"
  [ "$(hostname)" = "$EXPECTED_HOST" ] || warn "hostname is '$(hostname)', expected '$EXPECTED_HOST'"
  VAI_SOURCED="no (/etc/vai.sh not present)"
  if [ -f /etc/vai.sh ]; then
    set +u; # shellcheck disable=SC1091
    . /etc/vai.sh; set -u
    VAI_SOURCED="yes"
  fi
  [ -x "$PERF_BIN" ]  || fatal "Benchmark executable not found/executable: $PERF_BIN"
  [ -x "$VIDEO_BIN" ] || warn "Video executable not found: $VIDEO_BIN (not used by this script)"
  case "$THREADS$DURATION$RUNS$PROF_SEC" in *[!0-9]*) fatal "THREADS/DURATION/RUNS/PROF_SEC must be integers";; esac
  ensure_image_list
  command -v timeout >/dev/null 2>&1 || warn "'timeout' not found; hung runs will not be killed automatically"
  command -v xbutil  >/dev/null 2>&1 || warn "xbutil not found; per-CU execution verification unavailable"
  command -v xdputil >/dev/null 2>&1 || warn "xdputil not found; DPU arch/frequency capture limited"
  if command -v pgrep >/dev/null 2>&1 && pgrep -f 'test_performance_posedetect|vaitrace' >/dev/null 2>&1; then
    fatal "A benchmark/vaitrace process is already running; stop it first"
  fi
  local l1; read -r l1 _ < /proc/loadavg
  awk -v l="$l1" 'BEGIN{exit !(l>0.5)}' && warn "System load1=$l1 before start; results may be noisy"
  capture_env
  log "Preflight OK (output: $OUTDIR)"
}

# ------------------------------ one benchmark run ----------------------------
# run_bench <label> <mode> <threads> <seconds>
run_bench() {
  local label=$1 rmode=$2 thr=$3 sec=$4
  local base="$OUTDIR/$label" notes="" rc t0 t1 wall valid="yes"
  local fps e2e dpu cu1="NA" cu2="NA" names addrs
  # shellcheck disable=SC2206
  names=($DPU_CU_NAMES); addrs=($DPU_CU_ADDRS)

  snapshot_xrt "${base}_xrt_before.txt"; snapshot_irq "${base}_irq_before.txt"
  start_monitor "${base}_system.csv"
  log "RUN $label: threads=$thr duration=${sec}s"
  t0=$(now)
  if command -v timeout >/dev/null 2>&1; then
    timeout $((sec + TIMEOUT_MARGIN)) "$PERF_BIN" "$MODEL" -t "$thr" -s "$sec" -l "${base}.log" "$IMAGE_LIST" > "${base}_console.log" 2>&1
  else
    "$PERF_BIN" "$MODEL" -t "$thr" -s "$sec" -l "${base}.log" "$IMAGE_LIST" > "${base}_console.log" 2>&1
  fi
  rc=$?
  t1=$(now)
  stop_monitor
  snapshot_xrt "${base}_xrt_after.txt"; snapshot_irq "${base}_irq_after.txt"
  wall=$(awk -v a="$t0" -v b="$t1" 'BEGIN{printf "%.1f",b-a}')

  fps=$(parse_metric FPS "${base}_console.log" "${base}.log")
  e2e=$(parse_metric E2E "${base}_console.log" "${base}.log")
  dpu=$(parse_metric DPU "${base}_console.log" "${base}.log")

  [ "$rc" -eq 0 ]    || { valid="no"; notes="${notes}EXIT_${rc};"; [ "$rc" -eq 124 ] && notes="${notes}TIMED_OUT;"; }
  is_num "$fps"      || { valid="no"; notes="${notes}FPS_PARSE_FAIL;"; }
  is_num "$e2e"      || { valid="no"; notes="${notes}E2E_PARSE_FAIL;"; }
  is_num "$dpu"      || { valid="no"; notes="${notes}DPU_PARSE_FAIL;"; }
  awk -v w="$wall" -v s="$sec" 'BEGIN{exit !(w < s-2)}' && { valid="no"; notes="${notes}SHORT_RUN(${wall}s<${sec}s);"; }
  awk -v w="$wall" -v s="$sec" 'BEGIN{exit !(w > s+30)}' && notes="${notes}LONG_RUN(${wall}s);"
  grep -aqiE 'segmentation|core dumped|cannot|error|fail' "${base}_console.log" && notes="${notes}CONSOLE_MENTIONS_ERROR;"

  [ "${#names[@]}" -ge 1 ] && cu1=$(cu_delta "${base}_xrt_before.txt" "${base}_xrt_after.txt" "${names[0]}" "${addrs[0]}")
  [ "${#names[@]}" -ge 2 ] && cu2=$(cu_delta "${base}_xrt_before.txt" "${base}_xrt_after.txt" "${names[1]}" "${addrs[1]}")

  [ -f "$RESULTS" ] || echo "label,mode,threads,req_sec,wall_s,rc,fps,e2e_us,dpu_us,valid,cu1_delta,cu2_delta,notes" > "$RESULTS"
  echo "$label,$rmode,$thr,$sec,$wall,$rc,${fps:-NA},${e2e:-NA},${dpu:-NA},$valid,$cu1,$cu2,${notes:-none}" >> "$RESULTS"
  [ "$valid" = "yes" ] || FAILED_RUNS=$((FAILED_RUNS+1))
  log "  -> valid=$valid rc=$rc wall=${wall}s FPS=${fps:-NA} E2E=${e2e:-NA}us DPU=${dpu:-NA}us CU1+=$cu1 CU2+=$cu2 ${notes:+notes=$notes}"
}

do_baseline() {
  log "=== UNINSTRUMENTED BASELINE: $RUNS x ${DURATION}s, threads=$THREADS ==="
  if [ "$WARMUP_SEC" -gt 0 ]; then
    run_bench "warmup" "warmup" "$THREADS" "$WARMUP_SEC"; sleep "$COOLDOWN"
  fi
  local i
  for i in $(seq 1 "$RUNS"); do
    run_bench "baseline_run$i" "baseline" "$THREADS" "$DURATION"
    [ "$i" -lt "$RUNS" ] && sleep "$COOLDOWN"
  done
}

do_sweep() {
  log "=== THREAD SWEEP ($THREAD_LIST), $SWEEP_RUNS x ${DURATION}s each, uninstrumented ==="
  local t i
  for t in $THREAD_LIST; do
    for i in $(seq 1 "$SWEEP_RUNS"); do
      run_bench "sweep_t${t}_run$i" "sweep" "$t" "$DURATION"; sleep "$COOLDOWN"
    done
  done
}

# ------------------------------- profiling -----------------------------------
is_gzip() { [ "$(od -An -tx1 -N2 "$1" 2>/dev/null | tr -d ' \n')" = "1f8b" ]; }

# analyze_trace <file> : appends a human-readable analysis to trace_analysis.txt
# Raw data is never modified; gzip data is decompressed to a separate file.
analyze_trace() {
  local f=$1 out="$OUTDIR/trace_analysis.txt" txt="$f" kind
  mkdir -p "$OUTDIR/trace_raw"
  {
    echo "File: $f  ($(wc -c < "$f") bytes)"
    if is_gzip "$f"; then
      kind="gzip-compressed"
      txt="$OUTDIR/trace_raw/$(basename "$f").decompressed"
      cp -n "$f" "$OUTDIR/trace_raw/$(basename "$f").gz" 2>/dev/null
      if gzip -dc "$f" > "$txt" 2>/dev/null; then
        echo "Type: gzip-compressed (extension is misleading); decompressed to $txt ($(wc -c < "$txt") bytes)"
      else
        echo "Type: gzip magic present but decompression FAILED (truncated/corrupt trace?)"; echo; return 0
      fi
    else
      kind="uncompressed"
      echo "Type: not gzip"
    fi
    if grep -Iq . "$txt" 2>/dev/null; then echo "Content: text-like"; else echo "Content: binary/non-text (all greps use -a)"; fi
    echo "Keyword occurrence counts (indicative only):"
    printf '  %-34s %s\n' "dpu"                       "$(grep -aoi 'dpu' "$txt" | wc -l)"
    printf '  %-34s %s\n' "subgraph/runner"            "$(grep -aoiE 'subgraph|runner' "$txt" | wc -l)"
    printf '  %-34s %s\n' "xrt/zocl/xclbin"            "$(grep -aoiE 'xrt|zocl|xclbin' "$txt" | wc -l)"
    printf '  %-34s %s\n' "opencv/imread/imdecode"      "$(grep -aoiE 'opencv|cv::|imread|imdecode' "$txt" | wc -l)"
    printf '  %-34s %s\n' "timestamp-like fields"       "$(grep -aoiE 'timestamp|"ts"|start_time|end_time|duration' "$txt" | wc -l)"
    echo "Interpretation: this establishes which events were traced. DPU busy-time/utilization"
    echo "is NOT derived here; it requires timestamped DPU run begin/end events, and must not"
    echo "be inferred from metadata or OpenCV image-loading events alone."
    echo
  } >> "$out"
}

do_profile() {
  log "=== INSTRUMENTED PROFILE (vaitrace) -- not comparable to baseline without overhead accounting ==="
  local PROFDIR="$OUTDIR/profile" base="$OUTDIR/profile" help_txt vt_timeout rc t0 t1 wall marker
  local -a vt_args=()
  mkdir -p "$PROFDIR"
  if ! command -v vaitrace >/dev/null 2>&1; then
    warn "vaitrace not found; skipping profile"
    echo "vaitrace not available" > "$OUTDIR/vaitrace_status.txt"; return 0
  fi
  help_txt=$(vaitrace -h 2>&1 || true); echo "$help_txt" > "$OUTDIR/vaitrace_help.txt"
  vt_timeout=$((PROF_SEC + PROF_MARGIN))
  if echo "$help_txt" | grep -qE -- '(^|[[:space:]])-t([[:space:],]|$)'; then
    vt_args+=(-t "$vt_timeout")
  else
    warn "vaitrace help does not list -t; its default timeout applies and may truncate the run"
  fi
  # Config files can silently override the timeout (suspected cause of the earlier 10 s stop)
  find "$PROFDIR" "$PWD" "$HOME" -maxdepth 1 -name '*.json' 2>/dev/null | head -n 5 > "$OUTDIR/vaitrace_candidate_configs.txt"

  snapshot_xrt "${base}_xrt_before.txt"; start_monitor "${base}_system.csv"
  marker="$OUTDIR/.profile_marker"; : > "$marker"; sleep 1
  t0=$(now)
  ( cd "$PROFDIR" && vaitrace ${vt_args[@]+"${vt_args[@]}"} "$PERF_BIN" "$MODEL" -t "$THREADS" -s "$PROF_SEC" -l "$PROFDIR/profile_bench.log" "$IMAGE_LIST" ) > "$OUTDIR/vaitrace_console.log" 2>&1
  rc=$?
  t1=$(now); stop_monitor; snapshot_xrt "${base}_xrt_after.txt"
  wall=$(awk -v a="$t0" -v b="$t1" 'BEGIN{printf "%.1f",b-a}')

  local status="OK" fps e2e dpu
  awk -v w="$wall" -v s="$PROF_SEC" 'BEGIN{exit !(w < s-2)}' && status="DURATION_MISMATCH"
  grep -aqiE 'timeout|stopping' "$OUTDIR/vaitrace_console.log" && status="${status}+CONSOLE_REPORTS_TIMEOUT_OR_STOP"
  [ "$rc" -eq 0 ] || status="${status}+EXIT_$rc"
  fps=$(parse_metric FPS "$OUTDIR/vaitrace_console.log" "$PROFDIR/profile_bench.log")
  e2e=$(parse_metric E2E "$OUTDIR/vaitrace_console.log" "$PROFDIR/profile_bench.log")
  dpu=$(parse_metric DPU "$OUTDIR/vaitrace_console.log" "$PROFDIR/profile_bench.log")
  {
    echo "requested_app_duration_s=$PROF_SEC"
    echo "vaitrace_timeout_arg_s=${vt_args[1]:-not_set}"
    echo "observed_wall_s=$wall"
    echo "exit_code=$rc"
    echo "status=$status"
    echo "fps=${fps:-NA} e2e_us=${e2e:-NA} dpu_us=${dpu:-NA}"
  } > "$OUTDIR/vaitrace_status.txt"
  [ -f "$RESULTS" ] || echo "label,mode,threads,req_sec,wall_s,rc,fps,e2e_us,dpu_us,valid,cu1_delta,cu2_delta,notes" > "$RESULTS"
  local pv="yes"; { is_num "$fps" && is_num "$e2e" && is_num "$dpu"; } || pv="no"
  echo "profile,profile,$THREADS,$PROF_SEC,$wall,$rc,${fps:-NA},${e2e:-NA},${dpu:-NA},$pv,NA,NA,${status}" >> "$RESULTS"
  log "  -> profile status=$status wall=${wall}s (requested ${PROF_SEC}s) FPS=${fps:-NA}"
  case $status in *MISMATCH*) warn "Profile ended early: observed ${wall}s vs requested ${PROF_SEC}s -- trace is SHORTER than requested";; esac

  # Locate trace artefacts produced by vaitrace (new files only) and analyze them safely
  : > "$OUTDIR/trace_analysis.txt"
  local f found=0
  while IFS= read -r f; do
    case "$f" in */profile_bench.log|*_system.csv|*_xrt_*.txt) continue;; esac
    found=1; analyze_trace "$f"
  done < <(find "$PROFDIR" "$PWD" -maxdepth 3 -type f -newer "$marker" 2>/dev/null | sort -u)
  [ "$found" -eq 1 ] || echo "No new trace files located after vaitrace run." >> "$OUTDIR/trace_analysis.txt"
  rm -f "$marker"
}

# ------------------------------- reporting -----------------------------------
rebuild_results() {   # for legacy output dirs lacking results.csv
  local f label fps e2e dpu v
  echo "label,mode,threads,req_sec,wall_s,rc,fps,e2e_us,dpu_us,valid,cu1_delta,cu2_delta,notes" > "$RESULTS"
  for f in "$OUTDIR"/baseline_run*_console.log; do
    [ -e "$f" ] || continue
    label=$(basename "$f" _console.log)
    fps=$(parse_metric FPS "$f" "$OUTDIR/$label.log"); e2e=$(parse_metric E2E "$f" "$OUTDIR/$label.log"); dpu=$(parse_metric DPU "$f" "$OUTDIR/$label.log")
    v="yes"; { is_num "$fps" && is_num "$e2e" && is_num "$dpu"; } || v="no"
    echo "$label,baseline,$THREADS,$DURATION,NA,NA,${fps:-NA},${e2e:-NA},${dpu:-NA},$v,NA,NA,rebuilt_from_legacy_logs(threads/duration assumed)" >> "$RESULTS"
  done
}

stats() {   # mode threads
  awk -F, -v m="$1" -v t="$2" '
    NR>1 && $2==m && $3==t && $10=="yes" { n++; for(k=7;k<=9;k++){v=$k+0; s[k]+=v; ss[k]+=v*v; if(n==1||v<mn[k])mn[k]=v; if(n==1||v>mx[k])mx[k]=v} }
    END { if(!n){print "  no valid runs"; exit}
      split("FPS E2E_us DPU_us",nm," "); printf "  valid runs: %d\n", n
      for(k=7;k<=9;k++){ mean=s[k]/n; var=(n>1)?(ss[k]-n*mean*mean)/(n-1):0; if(var<0)var=0; sd=sqrt(var)
        printf "  %-7s mean=%.3f sd=%.3f cv=%.3f%% min=%.3f max=%.3f\n", nm[k-6], mean, sd, (mean?100*sd/mean:0), mn[k], mx[k] } }' "$RESULTS"
}
col_mean() { awk -F, -v m="$1" -v t="$2" -v c="$3" 'NR>1&&$2==m&&$3==t&&$10=="yes"{s+=$c;n++}END{if(n)printf "%.3f",s/n}' "$RESULTS"; }
pct() { awk -v a="$1" -v b="$2" 'BEGIN{ if(b==0){print "NA"} else printf "%+.2f%%",100*(a-b)/b }'; }

sys_summary() {   # csv files...
  [ "$#" -gt 0 ] || { echo "  (no monitor data)"; return; }
  awk -F, 'FNR>1 { if($2!=""){c+=$2;n++; if($2>cm)cm=$2}
                   if($5!=""&&$5>tm)tm=$5; if($4!=""&&(mm==""||$4<mm))mm=$4; if($3!=""&&$3>lm)lm=$3; if($6!="")f=$6 }
           END { if(!n){print "  (no samples)"; exit}
                 printf "  samples=%d  cpu_busy(aggregate): mean=%.1f%% max=%.1f%%  load1_max=%s  min_mem_avail=%sMB  max_temp=%sC  cpu_mhz(last)=%s\n", n,c/n,cm,lm,mm,(tm==""?"NA":tm),(f==""?"NA":f) }' "$@"
}

generate_report() {
  [ -f "$RESULTS" ] || rebuild_results
  local rep="$OUTDIR/report.txt" combos m t F E D pF pE pD o
  {
    echo "==================== ZCU104 PoseDetect benchmark report ===================="
    echo "Output dir : $OUTDIR"
    echo "Generated  : $(date)"
    echo "Model      : $MODEL   Binary: $PERF_BIN"
    [ -f "$OUTDIR/env.txt" ] && { echo; echo "--- Environment ---"; sed -n '1,12p' "$OUTDIR/env.txt"; }
    [ -f "$OUTDIR/posedetect_images.txt" ] && echo "Image list : $(grep -c . "$OUTDIR/posedetect_images.txt") entries (copied to output dir)"

    echo; echo "--- Per-run results (raw: results.csv) ---"
    column -s, -t "$RESULTS" 2>/dev/null || cat "$RESULTS"

    echo; echo "--- UNINSTRUMENTED statistics (invalid runs excluded) ---"
    combos=$(awk -F, 'NR>1 && ($2=="baseline"||$2=="sweep"){print $2","$3}' "$RESULTS" | sort -u)
    if [ -z "$combos" ]; then echo "  none"; fi
    for o in $combos; do
      m=${o%,*}; t=${o#*,}
      echo "[$m, threads=$t]"; stats "$m" "$t"
      F=$(col_mean "$m" "$t" 7); E=$(col_mean "$m" "$t" 8); D=$(col_mean "$m" "$t" 9)
      if is_num "$F" && is_num "$E" && is_num "$D"; then
        awk -v F="$F" -v E="$E" -v D="$D" -v t="$t" 'BEGIN{
          printf "  derived: DPU share of E2E = %.1f%%, non-DPU (pre/post/queue) = %.2f us\n", 100*D/E, E-D
          printf "  consistency: threads*1e6/E2E = %.1f FPS vs measured %.1f FPS\n", t*1e6/E, F
          printf "  ESTIMATE (not measured): FPS*DPU_mean = %.3f DPU-seconds/second.\n", F*D/1e6
          printf "           If one core did all work -> ~%.0f%% busy; if split evenly over 2 cores -> ~%.0f%% each.\n", 100*F*D/1e6, 50*F*D/1e6 }'
      fi
      if [ "$m" = "baseline" ] && [ "$t" = "1" ] && is_num "$F"; then
        echo "  vs historical (reference only, different sessions):"
        echo "    set1 (600.214 FPS/1664.22us/1370.11us): FPS $(pct "$F" $HIST1_FPS)  E2E $(pct "$E" $HIST1_E2E)  DPU $(pct "$D" $HIST1_DPU)"
        echo "    set2 (596.611 FPS/1674.10us/1377.57us): FPS $(pct "$F" $HIST2_FPS)  E2E $(pct "$E" $HIST2_E2E)  DPU $(pct "$D" $HIST2_DPU)"
      fi
    done

    echo; echo "--- DPU core execution verification ---"
    awk -F, 'NR>1 && $2!="profile" && $12!="" {
        if($11!="NA"){a+=$11;an++}; if($12!="NA"){b+=$12;bn++} }
      END{
        printf "  XRT CU usage-counter deltas summed over runs: CU1(DPUCZDX8G_1)=%s  CU2(DPUCZDX8G_2)=%s\n",(an?a:"NA"),(bn?b:"NA");
        if(!an && !bn) print "  Verdict: UNAVAILABLE -- xbutil usage counters could not be parsed; core-level utilization unknown.";
        else if(a>0 && b>0) print "  Verdict: BOTH CUs executed work (counters advanced on both).";
        else if(a>0 || b>0) print "  Verdict: ONLY ONE CU executed work in these runs; the second is present but idle.";
        else print "  Verdict: counters did not advance -- not conclusive (counter may not track this runtime path).";
      }' "$RESULTS"
    echo "  Note: presence of two CUs in XRT does not prove both were used. Counter deltas are the evidence;"
    echo "  raw before/after snapshots are kept as *_xrt_before.txt / *_xrt_after.txt."
    local f; for f in "$OUTDIR"/baseline_run1_irq_before.txt; do
      if [ -f "$f" ]; then echo "  Interrupt-count deltas (baseline_run1, DPU/XRT-looking IRQs; heuristic only):"
        irq_delta_report "$f" "${f%_before.txt}_after.txt" | head -n 10; fi
    done

    echo; echo "--- System monitor (uninstrumented runs) ---"
    # shellcheck disable=SC2046
    sys_summary $(ls "$OUTDIR"/baseline_run*_system.csv "$OUTDIR"/sweep_*_system.csv 2>/dev/null)
    echo "  (aggregate CPU over all cores: a single saturated core of four ~ 25%.)"

    echo; echo "--- INSTRUMENTED profiling (vaitrace) -- separate from baseline ---"
    if [ -f "$OUTDIR/vaitrace_status.txt" ]; then
      sed 's/^/  /' "$OUTDIR/vaitrace_status.txt"
      pF=$(awk -F, '$1=="profile"&&$10=="yes"{print $7}' "$RESULTS"); pE=$(awk -F, '$1=="profile"&&$10=="yes"{print $8}' "$RESULTS"); pD=$(awk -F, '$1=="profile"&&$10=="yes"{print $9}' "$RESULTS")
      if is_num "$pF"; then
        F=$(col_mean baseline "$THREADS" 7)
        echo "  instrumented FPS=$pF E2E=${pE}us DPU=${pD}us"
        is_num "$F" && echo "  overhead vs this session's baseline mean ($F FPS): FPS $(pct "$pF" "$F")"
        echo "  historical vaitrace run: $HIST_VT_FPS FPS / $HIST_VT_E2E us / $HIST_VT_DPU us"
      fi
      echo "  Profiled numbers carry instrumentation overhead; do not mix them with baseline."
    else
      echo "  no vaitrace status file found (profile not run, or legacy directory)."
    fi
    # Legacy handling: a gzip trace sitting under a .txt name
    local lf
    for lf in "$OUTDIR/vaitrace_summary.txt" "$OUTDIR"/*.xat "$OUTDIR"/*.xat.gz; do
      [ -f "$lf" ] || continue
      if is_gzip "$lf" && ! grep -qF "File: $lf" "$OUTDIR/trace_analysis.txt" 2>/dev/null; then analyze_trace "$lf"; fi
    done
    [ -f "$OUTDIR/trace_analysis.txt" ] && { echo; echo "  Trace analysis:"; sed 's/^/    /' "$OUTDIR/trace_analysis.txt"; }
    if [ -f "$OUTDIR/vaitrace_console.log" ] && [ ! -f "$OUTDIR/vaitrace_status.txt" ]; then
      echo "  Legacy console duration hints:"; grep -aiE 'timeout|stopping|second|[0-9]+ ?s' "$OUTDIR/vaitrace_console.log" | head -n 5 | sed 's/^/    /'
    fi

    echo; echo "--- Validity flags ---"
    awk -F, 'NR>1 && ($10!="yes" || $13!="none") {printf "  %s: valid=%s notes=%s\n",$1,$10,$13; n++} END{if(!n)print "  none"}' "$RESULTS"

    echo; echo "--- Caveats ---"
    echo "  * Historical tables in the task description are references, not results of this run."
    echo "  * 'DPU mean' is the library-reported per-task time, not measured DPU busy-time."
    echo "  * Clock/thermal state is in *_system.csv; compare max_temp and cpu_mhz across runs."
    echo "  * PoseDetect benchmark measures throughput/latency only; it does not measure accuracy."
    echo "=============================================================================="
  } > "$rep"
  cat "$rep"
  log "Report written: $rep"
}

# ---------------------------------- main -------------------------------------
case "$MODE" in
  help|-h|--help) usage; exit 0;;
  check|baseline|sweep|profile|all|report) ;;
  *) echo "Unknown mode: $MODE" >&2; usage; exit 1;;
esac

if [ "$MODE" = "report" ]; then
  OUTDIR=${2:-${OUTDIR:-}}
  [ -n "$OUTDIR" ] && [ -d "$OUTDIR" ] || { echo "report mode needs an existing output dir: $0 report <dir>" >&2; exit 1; }
  RESULTS="$OUTDIR/results.csv"
  generate_report; exit 0
fi

OUTDIR=${OUTDIR:-$OUT_BASE/zcu104_posedetect_$(date +%Y%m%d_%H%M%S)}
mkdir -p "$OUTDIR" || { echo "Cannot create $OUTDIR" >&2; exit 1; }
RESULTS="$OUTDIR/results.csv"
acquire_lock
log "Mode=$MODE  output=$OUTDIR"
preflight

case "$MODE" in
  check)    log "Check complete."; exit 0;;
  baseline) do_baseline; generate_report;;
  sweep)    do_sweep;    generate_report;;
  profile)  do_profile;  generate_report;;
  all)      do_baseline
            [ "$SWEEP" = "1" ] && do_sweep
            sleep "$COOLDOWN"; do_profile; generate_report;;
esac

if [ "$FAILED_RUNS" -gt 0 ]; then
  log "$FAILED_RUNS run(s) flagged invalid; see report.txt and raw logs in $OUTDIR"
  exit 2
fi
exit 0
