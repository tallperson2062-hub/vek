#!/usr/bin/env python3
"""VEK280 YOLOv7 - pipelined end-to-end system profiler (board-side).

METHOD (reproduces the earlier ~70 FPS design, newly written for vart_ml):
  * NPU-only runner (CPU subgraph skipped) fed NATIVE INT8 NHWC4 (1,640,640,4):
    input = round(x/255*128) capped at 127 (equals min(127,(x+1)>>1)), pad value lut[114].
    Avoids VART's per-call float32->INT8 conversion (that conversion was ~65 ms/frame).
  * Raw NPU heads (NHWC8, coeff 8) decoded in numpy (objectness thresholded on INT8
    first), class-agnostic NMS, boxes + labels drawn on the original-size frame.
  * 2 producer processes (JPEG read, letterbox, prep) -> main process (NPU call) ->
    1 decoder process (decode, NMS, draw), K in-flight slots in shared memory.
    Workers are forked BEFORE VART is initialised.
Reported separately:
  (1) ISOLATED NPU: runner.run() only, wall + CPU time, no application work.
  (2) PIPELINED APPLICATION E2E: JPEG read + prep + NPU + decode + NMS + draw, wall clock.
CPU util from /proc/stat; memory from /proc; NPU/AIE utilization is NOT estimated.
Accuracy: --dump-dets writes COCO-format detections (use --conf 0.001) to score on a PC.
Run:  source /etc/vai.sh; python3 03_e2e_system_profile.py
"""
import os, sys, glob, time, mmap, json, csv, argparse, threading, statistics, multiprocessing as mp
import numpy as np, cv2
try:
    import simplejpeg
except Exception:
    simplejpeg = None

SNAP = "/root/vek280_yolov7_profile/assets/snapshot.VE2802_NPU_IP_O00_A304_M3.yolov7.TF"
H = W = 640
ANCHORS = [[(12,16),(19,36),(40,28)], [(36,75),(76,55),(72,146)], [(142,110),(192,243),(459,401)]]
STRIDES = [8, 16, 32]
COCO = ("person bicycle car motorcycle airplane bus train truck boat traffic_light fire_hydrant stop_sign "
        "parking_meter bench bird cat dog horse sheep cow elephant bear zebra giraffe backpack umbrella handbag "
        "tie suitcase frisbee skis snowboard sports_ball kite baseball_bat baseball_glove skateboard surfboard "
        "tennis_racket bottle wine_glass cup fork knife spoon bowl banana apple sandwich orange broccoli carrot "
        "hot_dog pizza donut cake chair couch potted_plant bed dining_table toilet tv laptop mouse remote keyboard "
        "cell_phone microwave oven toaster sink refrigerator book clock vase scissors teddy_bear hair_drier "
        "toothbrush").split()
COCO91 = [1,2,3,4,5,6,7,8,9,10,11,13,14,15,16,17,18,19,20,21,22,23,24,25,27,28,31,32,33,34,35,36,37,38,39,40,
          41,42,43,44,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,67,70,72,73,74,75,76,77,78,
          79,80,81,82,84,85,86,87,88,89,90]
pc = time.perf_counter

NEON_SRC = r"""
#include <stdint.h>
#ifdef __ARM_NEON
#include <arm_neon.h>
#endif
// BGR uint8 -> RGBA INT8-range (min(127,(v+1)>>1)), alpha 0, written into NHWC4 rows.
extern "C" void prep_bgr_to_nhwc4(const uint8_t* src, int h, int w, long sstride, uint8_t* dst, long dstride) {
    for (int y = 0; y < h; ++y) {
        const uint8_t* s = src + (long)y * sstride; uint8_t* d = dst + (long)y * dstride; int x = 0;
#ifdef __ARM_NEON
        const uint8x16_t cap = vdupq_n_u8(127), zero = vdupq_n_u8(0);
        for (; x + 16 <= w; x += 16) {
            uint8x16x3_t bgr = vld3q_u8(s + 3 * x); uint8x16x4_t o;
            o.val[0] = vminq_u8(vrshrq_n_u8(bgr.val[2], 1), cap);
            o.val[1] = vminq_u8(vrshrq_n_u8(bgr.val[1], 1), cap);
            o.val[2] = vminq_u8(vrshrq_n_u8(bgr.val[0], 1), cap);
            o.val[3] = zero; vst4q_u8(d + 4 * x, o);
        }
#endif
        for (; x < w; ++x) {
            unsigned b = s[3*x], g = s[3*x+1], r = s[3*x+2];
            unsigned rb = (r + 1) >> 1, gb = (g + 1) >> 1, bb = (b + 1) >> 1;
            d[4*x] = rb > 127 ? 127 : rb; d[4*x+1] = gb > 127 ? 127 : gb; d[4*x+2] = bb > 127 ? 127 : bb; d[4*x+3] = 0;
        }
    }
}
"""

def build_prep(lut4):
    """Compile (once, g++ -O3) and self-check the prep kernel against cv2 cvtColor+LUT. Returns fn or None."""
    import ctypes, subprocess
    d = os.path.join(os.path.dirname(os.path.abspath(__file__)), "build_prep")
    os.makedirs(d, exist_ok=True); src = os.path.join(d, "prep.cpp"); so = os.path.join(d, "libprep.so")
    open(src, "w").write(NEON_SRC)
    subprocess.run(["g++", "-O3", "-shared", "-fPIC", "-o", so, src], check=True)
    fn = ctypes.CDLL(so).prep_bgr_to_nhwc4
    fn.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_int, ctypes.c_long, ctypes.c_void_p, ctypes.c_long]
    img = np.random.RandomState(0).randint(0, 256, (37, 53, 3), np.uint8)   # odd width exercises the scalar tail
    ref = np.zeros((37, 53, 4), np.uint8); cv2.LUT(cv2.cvtColor(img, cv2.COLOR_BGR2RGBA), lut4, dst=ref)
    out = np.zeros((37, 53, 4), np.uint8); fn(img.ctypes.data, 37, 53, img.strides[0], out.ctypes.data, out.strides[0])
    return fn if np.array_equal(ref, out) else None

def read_jpeg(path):
    data = open(path, "rb").read()
    if simplejpeg is not None:
        try: return simplejpeg.decode_jpeg(data, colorspace="BGR")
        except Exception: pass
    return cv2.imdecode(np.frombuffer(data, np.uint8), cv2.IMREAD_COLOR)

def decode(outs, conf, coeff=8.0):
    """YOLOv7 head decode of the 3 raw NPU outputs. INT8 outputs: threshold in INT domain."""
    isint = np.issubdtype(outs[0].dtype, np.integer)
    t = np.log(conf / (1 - conf)); thr = int(np.ceil(t * coeff)) if isint else t
    c_ = coeff if isint else 1.0
    B, S, C = [], [], []
    for l, o in enumerate(outs):
        o = o[0]; h, w, _ = o.shape
        o = o[..., :255].reshape(h, w, 3, 85)
        m = o[..., 4] >= thr
        if not m.any(): continue
        ys, xs, a = np.nonzero(m)
        p = 1 / (1 + np.exp(-(o[ys, xs, a].astype(np.float32) / c_)))
        anc = np.array(ANCHORS[l], np.float32)[a]
        xy = (p[:, :2] * 2 - 0.5 + np.stack([xs, ys], 1)) * STRIDES[l]
        wh = (p[:, 2:4] * 2) ** 2 * anc
        c = p[:, 5:]; ci = c.argmax(1); s = p[:, 4] * c[np.arange(len(ci)), ci]
        k = s >= conf
        B.append(np.concatenate([xy - wh / 2, xy + wh / 2], 1)[k]); S.append(s[k]); C.append(ci[k])
    if not B: return np.zeros((0, 4), np.float32), np.zeros(0, np.float32), np.zeros(0, int)
    return np.concatenate(B), np.concatenate(S), np.concatenate(C)

def stats(v):
    if not v: return {}
    return {"mean": statistics.fmean(v), "median": statistics.median(v), "min": min(v),
            "max": max(v), "std": statistics.pstdev(v) if len(v) > 1 else 0.0}

def read_stat():
    d = {}
    for l in open("/proc/stat"):
        if l.startswith("cpu"):
            p = l.split(); v = list(map(int, p[1:9])); d[p[0]] = (sum(v), v[3] + v[4])
    return d

def rss_mb(pid):
    try:
        for l in open(f"/proc/{pid}/status"):
            if l.startswith("VmRSS"): return int(l.split()[1]) / 1024
    except Exception: pass
    return 0.0

class Sampler(threading.Thread):
    def __init__(self, pids, dt=0.2):
        super().__init__(daemon=True); self.dt, self.pids = dt, pids
        self.stop = threading.Event(); self.cpu = []; self.rss_peak = 0.0
    def run(self):
        prev = read_stat()
        while not self.stop.wait(self.dt):
            cur = read_stat()
            self.cpu.append({k: 100.0 * (1 - (cur[k][1]-prev[k][1]) / max(1, cur[k][0]-prev[k][0])) for k in cur})
            prev = cur
            self.rss_peak = max(self.rss_peak, sum(rss_mb(p) for p in self.pids))

def probe_aie():
    keys = ("util", "busy", "active", "counter", "perf", "load", "occupancy")
    found = []
    for root in ("/sys/class/aie", "/sys/devices/platform/pl-bus/81000000.npu_versal_0"):
        for dp, dn, fn in os.walk(root, followlinks=False):
            found += [os.path.join(dp, f) for f in fn if any(k in f.lower() for k in keys)]
    return found, ("candidate counters found (meaning not verified; NOT used)" if found else
                   "NPU/AIE utilization: unavailable through exposed runtime counters")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--images", default="/root/vek280_yolov7_profile/images")
    ap.add_argument("--limit", type=int, default=100)
    ap.add_argument("--k", type=int, default=5, help="in-flight slots")
    ap.add_argument("--nprod", type=int, default=2, help="producer processes")
    ap.add_argument("--conf", type=float, default=0.25)
    ap.add_argument("--npu-iters", type=int, default=200)
    ap.add_argument("--neon-prep", action="store_true", help="compile+use a C++ prep kernel (self-checked vs cv2)")
    ap.add_argument("--no-labels", action="store_true", help="draw boxes only (no text labels)")
    ap.add_argument("--float-out", action="store_true", help="do not request native INT8 outputs")
    ap.add_argument("--save-annotated", type=int, default=5, help="save first N annotated images (0=none)")
    ap.add_argument("--dump-dets", default=None, help="write COCO-format detections JSON here")
    ap.add_argument("--out", default="/root/vek280_yolov7_profile/results")
    a = ap.parse_args()
    files = sorted(glob.glob(os.path.join(a.images, "[0-9]*.jpg")))[:a.limit]
    if not files: sys.exit("ERROR: no numbered JPEGs in " + a.images)
    os.makedirs(a.out, exist_ok=True)
    ann_dir = os.path.join(a.out, "annotated")
    if a.save_annotated: os.makedirs(ann_dir, exist_ok=True)
    K, NPROD = a.k, a.nprod
    IN_B, FR_B, OUT_B = H * W * 4, H * W * 3, 32 * 1024 * 1024
    in_mem = [mmap.mmap(-1, IN_B) for _ in range(K)]
    fr_mem = [mmap.mmap(-1, FR_B) for _ in range(K)]
    out_mem = [mmap.mmap(-1, OUT_B) for _ in range(K)]
    in_arr = [np.frombuffer(m, np.uint8).reshape(1, H, W, 4) for m in in_mem]
    fr_arr = [np.frombuffer(m, np.uint8).reshape(H, W, 3) for m in fr_mem]
    lut = np.clip(np.round(np.arange(256) / 255.0 * 128.0), 0, 127).astype(np.uint8)
    lut4 = np.zeros((256, 1, 4), np.uint8); lut4[:, 0, :3] = lut[:, None]
    PAD = np.zeros((1, H, W, 4), np.uint8); PAD[..., :3] = lut[114]
    prep_fn = None
    if a.neon_prep:
        prep_fn = build_prep(lut4)
        print("prep kernel:", "g++ kernel, verified byte-identical to cv2 cvtColor+LUT" if prep_fn else "SELF-CHECK FAILED -> using cv2 path")
    ctx = mp.get_context("fork")
    work_q, free_q, ready_in, ready_out = ctx.Queue(), ctx.Queue(), ctx.Queue(), ctx.Queue()
    config_q, prod_ready, dec_ready, go = ctx.Queue(), ctx.Queue(), ctx.Queue(), ctx.Event()
    pstats_q, dres_q = ctx.Queue(), ctx.Queue()
    geom_sh = ctx.Array("q", K * 6, lock=False)
    for i, p in enumerate(files): work_q.put((i, p))
    for _ in range(NPROD): work_q.put(None)
    for k in range(K): free_q.put(k)

    def producer():
        cv2.setNumThreads(1)
        rgba = np.empty((H, W, 4), np.uint8)
        rs = zs = ps = 0.0; cnt = err = 0; etxt = None
        prod_ready.put(True); go.wait()
        try:
            while True:
                it = work_q.get()
                if it is None: break
                idx, path = it
                k = free_q.get(); t_start = pc()
                img = read_jpeg(path); rs += pc() - t_start
                if img is None:
                    err += 1; free_q.put(k); continue
                h, w = img.shape[:2]; fr_arr[k][:h, :w] = img
                t = pc(); sc = min(W / h, H / w)
                nh, nw = int(round(h * sc)), int(round(w * sc)); dy, dx = (H - nh) // 2, (W - nw) // 2
                g = (h, w, nh, nw, dy, dx); base = k * 6
                if tuple(geom_sh[base + j] for j in range(6)) != g:
                    np.copyto(in_arr[k], PAD)
                    for j, v in enumerate(g): geom_sh[base + j] = v
                small = img if (nh, nw) == (h, w) else cv2.resize(img, (nw, nh))
                zs += pc() - t; t = pc()
                if prep_fn is not None:
                    small = np.ascontiguousarray(small)
                    prep_fn(small.ctypes.data, nh, nw, small.strides[0], in_arr[k].ctypes.data + (dy * W + dx) * 4, W * 4)
                else:
                    roi = in_arr[k][0, dy:dy + nh, dx:dx + nw]
                    cv2.cvtColor(small, cv2.COLOR_BGR2RGBA, dst=rgba[:nh, :nw])
                    cv2.LUT(rgba[:nh, :nw], lut4, dst=roi)
                ps += pc() - t
                ready_in.put((k, idx, h, w, sc, dy, dx, t_start)); cnt += 1
        except Exception as e:
            etxt = repr(e)
        finally:
            ready_in.put(None); pstats_q.put((cnt, err, rs, zs, ps, etxt, time.process_time()))

    def decoder():
        cv2.setNumThreads(1)
        meta = config_q.get(); dec_ready.put(True)
        n = nd = 0; ds = ns = rw = 0.0; rows = []; dets = []; etxt = None
        try:
            while True:
                it = ready_out.get()
                if it is None: break
                k, idx, h, w, sc, dy, dx, t_start, npu_ms = it
                outs = [np.frombuffer(out_mem[k], dtype=np.dtype(dt), count=int(np.prod(s)), offset=off).reshape(s)
                        for s, dt, off, nb in meta]
                t = pc(); b, s_, c = decode(outs, a.conf); ds += pc() - t
                t = pc()
                if len(s_):
                    xywh = np.stack([b[:, 0], b[:, 1], b[:, 2] - b[:, 0], b[:, 3] - b[:, 1]], 1)
                    keep = np.asarray(cv2.dnn.NMSBoxes(xywh.tolist(), s_.tolist(), a.conf, 0.45)).reshape(-1)
                    b, s_, c = b[keep], s_[keep], c[keep]
                ns += pc() - t; t = pc()
                img = fr_arr[k][:h, :w]; name = os.path.basename(files[idx])
                for (x1, y1, x2, y2), sco, cl in zip(b, s_, c):
                    x1, x2 = float(np.clip((x1 - dx) / sc, 0, w)), float(np.clip((x2 - dx) / sc, 0, w))
                    y1, y2 = float(np.clip((y1 - dy) / sc, 0, h)), float(np.clip((y2 - dy) / sc, 0, h))
                    cv2.rectangle(img, (int(x1), int(y1)), (int(x2), int(y2)), (0, 255, 0), 2)
                    if not a.no_labels:
                        cv2.putText(img, f"{COCO[cl]} {sco:.2f}", (int(x1), max(12, int(y1) - 4)),
                                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1)
                    if a.dump_dets:
                        dets.append({"image_id": int(os.path.splitext(name)[0]), "category_id": COCO91[int(cl)],
                                     "bbox": [x1, y1, x2 - x1, y2 - y1], "score": float(sco)})
                rw += pc() - t
                if idx < a.save_annotated: cv2.imwrite(os.path.join(ann_dir, name), img, [cv2.IMWRITE_JPEG_QUALITY, 85])
                lat = (pc() - t_start) * 1e3
                rows.append({"image": name, "e2e_latency_ms": lat, "npu_ms": npu_ms, "n_det": int(len(s_))})
                nd += len(s_); n += 1; free_q.put(k)
        except Exception as e:
            etxt = repr(e)
        finally:
            dres_q.put((n, nd, ds, ns, rw, rows, dets, etxt, time.process_time()))

    procs = [ctx.Process(target=producer) for _ in range(NPROD)] + [ctx.Process(target=decoder)]
    for p in procs: p.start()
    try:
        for _ in range(NPROD): prod_ready.get(timeout=60)
        sys.path.insert(0, "/etc/vai/lib/python"); import vart_ml
        tl = pc()
        runner = vart_ml.VartMLRunner(SNAP, network_name="wrp_network", npu_only=True)
        runner.set_input_native()
        if not a.float_out: runner.set_output_native()
        load_s = pc() - tl
        np.copyto(in_arr[0], PAD)
        x0 = in_arr[0].view(np.int8)
        tw = pc(); warm = None
        for _ in range(6): warm = runner.run(x0)
        warm_s = pc() - tw
        meta, off = [], 0
        for o in warm:
            o = np.ascontiguousarray(o); meta.append((o.shape, o.dtype.str, off, o.nbytes)); off += o.nbytes
        if off > OUT_B: raise RuntimeError("outputs exceed shared buffer")
        out_desc = [(m[0], m[1]) for m in meta]
        # (1) isolated NPU: runner.run() only
        wall, cpu0 = [], time.process_time()
        for _ in range(a.npu_iters):
            t = pc(); runner.run(x0); wall.append((pc() - t) * 1e3)
        npu_cpu_ms = (time.process_time() - cpu0) * 1e3 / a.npu_iters
        iso = {"iters": a.npu_iters, "run_ms": stats(wall), "cpu_ms_per_call": npu_cpu_ms,
               "fps_isolated": 1000.0 / statistics.fmean(wall)}
        config_q.put(meta); dec_ready.get(timeout=60)
        cores = open("/sys/devices/system/cpu/online").read().strip()
        aie_files, aie_verdict = probe_aie()
        mem0 = {l.split(":")[0]: int(l.split()[1]) for l in open("/proc/meminfo")}
        smp = Sampler([os.getpid()] + [p.pid for p in procs]); smp.start()
        # (2) pipelined application E2E
        t0 = pc(); go.set(); fin = 0; npu_ms_l = []
        while True:
            it = ready_in.get(timeout=120)
            if it is None:
                fin += 1
                if fin == NPROD: break
                continue
            k = it[0]
            t = pc(); outs = runner.run(in_arr[k].view(np.int8)); nm = (pc() - t) * 1e3
            npu_ms_l.append(nm); off = 0
            for o in outs:
                o = np.ascontiguousarray(o)
                np.frombuffer(out_mem[k], np.uint8, count=o.nbytes, offset=off)[:] = o.view(np.uint8).reshape(-1)
                off += o.nbytes
            ready_out.put(it + (nm,))
        ready_out.put(None)
        pst = [pstats_q.get(timeout=120) for _ in range(NPROD)]
        dres = dres_q.get(timeout=120); wall_s = pc() - t0
        smp.stop.set(); smp.join(); main_cpu = time.process_time()
        for p in procs: p.join(timeout=10)
    finally:
        go.set()
        for p in procs:
            if p.is_alive(): p.terminate()
            p.join(timeout=5)
    n, nd, ds, ns, rw, rows, dets, derr, dcpu = dres
    pn = sum(x[0] for x in pst); perr = sum(x[1] for x in pst)
    pe = "; ".join(x[5] for x in pst if x[5]) or None
    rs, zs, ps = (sum(x[i] for x in pst) for i in (2, 3, 4))
    cpu_avg = {k: sum(s[k] for s in smp.cpu) / len(smp.cpu) for k in smp.cpu[0]} if smp.cpu else {}
    stage = {"jpeg_read_ms": 1e3 * rs / pn, "resize_letterbox_ms": 1e3 * zs / pn, "input_prep_ms": 1e3 * ps / pn,
             "npu_call_ms": statistics.fmean(npu_ms_l), "yolo_decode_ms": 1e3 * ds / n, "nms_ms": 1e3 * ns / n,
             "draw_ms": 1e3 * rw / n}
    summ = {"images": len(files), "processed": n, "unreadable": perr, "avg_det_per_frame": nd / n,
            "conf": a.conf, "labels_drawn": not a.no_labels, "prep": "g++ kernel (self-checked)" if prep_fn else "cv2 cvtColor+LUT", "slots_K": K, "producers": NPROD, "jpeg_decoder": "simplejpeg" if simplejpeg else "cv2.imdecode",
            "model_load_s": load_s, "warmup_iters": 6, "warmup_s": warm_s,
            "output_tensors": [(list(s), d) for s, d in out_desc],
            "isolated_npu": iso,
            "pipelined_e2e": {"wall_s": wall_s, "fps_measured": n / wall_s, "ms_per_frame_wall": 1e3 * wall_s / n,
                              "frame_latency_ms": stats([r["e2e_latency_ms"] for r in rows]), "stage_avg_ms": stage},
            "process_cpu_s": {"producers": [x[6] for x in pst], "decoder": dcpu, "main_total_incl_startup": main_cpu},
            "cpu_cores_online": cores, "cpu_util_pct_avg_measured": cpu_avg, "cpu_sample_interval_s": smp.dt,
            "rss_peak_sum_MB_measured": smp.rss_peak, "memavailable_before_MB": mem0["MemAvailable"] / 1024,
            "npu_aie_utilization": aie_verdict, "aie_candidate_files": aie_files,
            "errors": {"producer": pe, "decoder": derr},
            "note": "Measured values only. Isolated NPU FPS is NOT application FPS. Power is separate (script 04)."}
    with open(os.path.join(a.out, "e2e_profile.json"), "w") as fh: json.dump({"summary": summ, "rows": rows}, fh, indent=2)
    with open(os.path.join(a.out, "e2e_profile.csv"), "w", newline="") as fh:
        w_ = csv.DictWriter(fh, list(rows[0])); w_.writeheader(); w_.writerows(rows)
    if a.dump_dets: json.dump(dets, open(a.dump_dets, "w"))
    print("\n=========== VEK280 YOLOv7 PROFILE ===========")
    print(f"images {n}/{len(files)}  unreadable {perr}  det/frame {nd/n:.2f} (conf {a.conf})  decoder {summ['jpeg_decoder']}  labels {not a.no_labels}  prep {summ['prep']}")
    print(f"model load {load_s:.2f}s  warm-up 6 iters {warm_s:.2f}s  outputs {summ['output_tensors']}")
    r = iso["run_ms"]
    print(f"[ISOLATED NPU, runner.run only] mean {r['mean']:.2f} med {r['median']:.2f} min {r['min']:.2f} max {r['max']:.2f} ms"
          f" -> {iso['fps_isolated']:.1f} FPS (CPU {npu_cpu_ms:.2f} ms/call)")
    print("[PIPELINED APPLICATION E2E] (read+prep+NPU+decode+NMS+draw)")
    for k, v in stage.items(): print(f"  {k:22s} {v:7.2f}")
    fl = summ["pipelined_e2e"]["frame_latency_ms"]
    print(f"  per-frame latency ms   mean {fl['mean']:.1f} med {fl['median']:.1f} max {fl['max']:.1f}")
    print(f"  E2E FPS (measured)     {n / wall_s:.2f}   wall {wall_s:.2f}s  K={K} producers={NPROD}")
    print(f"CPU cores online {cores}; CPU avg % {({k: round(v, 1) for k, v in cpu_avg.items()})}; RSS peak(sum) {smp.rss_peak:.0f} MB")
    print(aie_verdict); print("errors:", pe, derr)

if __name__ == "__main__":
    main()
