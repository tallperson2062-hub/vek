#!/usr/bin/env python3
"""VEK280 YOLOv7 live webcam: native INT8, NPU-only, latest-frame capture."""

import os
import sys
import time
import cv2
import numpy as np
import argparse
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

sys.path.insert(0, "/etc/vai/lib/python")

SNAP = "/root/vek280_yolov7_profile/assets/snapshot.VE2802_NPU_IP_O00_A304_M3.yolov7.TF"

H = W = 640
ANCHORS = [
    [(12, 16), (19, 36), (40, 28)],
    [(36, 75), (76, 55), (72, 146)],
    [(142, 110), (192, 243), (459, 401)]
]
STRIDES = [8, 16, 32]

COCO = (
    "person bicycle car motorcycle airplane bus train truck boat traffic_light "
    "fire_hydrant stop_sign parking_meter bench bird cat dog horse sheep cow "
    "elephant bear zebra giraffe backpack umbrella handbag tie suitcase frisbee "
    "skis snowboard sports_ball kite baseball_bat baseball_glove skateboard "
    "surfboard tennis_racket bottle wine_glass cup fork knife spoon bowl banana "
    "apple sandwich orange broccoli carrot hot_dog pizza donut cake chair couch "
    "potted_plant bed dining_table toilet tv laptop mouse remote keyboard "
    "cell_phone microwave oven toaster sink refrigerator book clock vase "
    "scissors teddy_bear hair_drier toothbrush"
).split()


def make_input_buffers():
    lut = np.clip(
        np.round(np.arange(256) / 255.0 * 128.0), 0, 127
    ).astype(np.uint8)

    lut4 = np.zeros((256, 1, 4), np.uint8)
    lut4[:, 0, :3] = lut[:, None]

    pad = np.zeros((1, H, W, 4), np.uint8)
    pad[..., :3] = lut[114]

    return lut4, pad


def preprocess(frame, input_array, lut4, rgba):
    h, w = frame.shape[:2]

    scale = min(W / w, H / h)
    nw = int(round(w * scale))
    nh = int(round(h * scale))

    dx = (W - nw) // 2
    dy = (H - nh) // 2

    np.copyto(input_array, PAD)

    resized = (
        frame if (nw, nh) == (w, h)
        else cv2.resize(frame, (nw, nh), interpolation=cv2.INTER_LINEAR)
    )

    cv2.cvtColor(
        resized, cv2.COLOR_BGR2RGBA, dst=rgba[:nh, :nw]
    )

    roi = input_array[0, dy:dy + nh, dx:dx + nw]
    cv2.LUT(rgba[:nh, :nw], lut4, dst=roi)

    return scale, dx, dy


def decode(outs, conf=0.25, coeff=8.0):
    isint = np.issubdtype(outs[0].dtype, np.integer)

    threshold = np.log(conf / (1.0 - conf))
    threshold = int(np.ceil(threshold * coeff)) if isint else threshold
    divisor = coeff if isint else 1.0

    boxes_all = []
    scores_all = []
    classes_all = []

    for level, output in enumerate(outs):
        o = output[0]
        h, w, channels = o.shape

        o = o[..., :255].reshape(h, w, 3, 85)

        mask = o[..., 4] >= threshold
        if not mask.any():
            continue

        ys, xs, anchors = np.nonzero(mask)

        selected = o[ys, xs, anchors].astype(np.float32)
        p = 1.0 / (1.0 + np.exp(-(selected / divisor)))

        anchor_sizes = np.asarray(ANCHORS[level], np.float32)[anchors]

        xy = (
            p[:, :2] * 2.0 - 0.5
            + np.stack([xs, ys], axis=1)
        ) * STRIDES[level]

        wh = (p[:, 2:4] * 2.0) ** 2 * anchor_sizes

        class_probs = p[:, 5:]
        class_ids = class_probs.argmax(axis=1)
        scores = p[:, 4] * class_probs[
            np.arange(len(class_ids)), class_ids
        ]

        keep = scores >= conf
        if not keep.any():
            continue

        boxes = np.concatenate(
            [xy - wh / 2.0, xy + wh / 2.0], axis=1
        )

        boxes_all.append(boxes[keep])
        scores_all.append(scores[keep])
        classes_all.append(class_ids[keep])

    if not boxes_all:
        return (
            np.zeros((0, 4), np.float32),
            np.zeros(0, np.float32),
            np.zeros(0, dtype=int)
        )

    return (
        np.concatenate(boxes_all),
        np.concatenate(scores_all),
        np.concatenate(classes_all)
    )


def postprocess(outs, scale, dx, dy, frame_shape, conf=0.25):
    boxes, scores, classes = decode(outs, conf)

    if len(scores):
        xywh = np.stack(
            [
                boxes[:, 0],
                boxes[:, 1],
                boxes[:, 2] - boxes[:, 0],
                boxes[:, 3] - boxes[:, 1]
            ],
            axis=1
        )

        keep = cv2.dnn.NMSBoxes(
            xywh.tolist(),
            scores.tolist(),
            conf,
            0.45
        )

        keep = np.asarray(keep).reshape(-1)

        boxes = boxes[keep]
        scores = scores[keep]
        classes = classes[keep]

    h, w = frame_shape[:2]
    detections = []

    for box, score, cls in zip(boxes, scores, classes):
        x1, y1, x2, y2 = box

        x1 = float(np.clip((x1 - dx) / scale, 0, w))
        x2 = float(np.clip((x2 - dx) / scale, 0, w))
        y1 = float(np.clip((y1 - dy) / scale, 0, h))
        y2 = float(np.clip((y2 - dy) / scale, 0, h))

        detections.append((x1, y1, x2, y2, float(score), int(cls)))

    return detections


def draw(frame, detections):
    for x1, y1, x2, y2, score, cls in detections:
        cv2.rectangle(
            frame,
            (int(x1), int(y1)),
            (int(x2), int(y2)),
            (0, 255, 0),
            2
        )

        label = COCO[cls] if cls < len(COCO) else str(cls)
        cv2.putText(
            frame,
            f"{label} {score:.2f}",
            (int(x1), max(15, int(y1) - 5)),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.5,
            (0, 255, 0),
            1
        )

    return frame



# Browser MJPEG stream. The inference loop publishes one annotated JPEG at a
# time; browser clients never access the camera or VART runner directly.
STREAM_LOCK = threading.Lock()
STREAM_STATE = {"jpeg": None, "running": True}

BROWSER_PAGE = """<!doctype html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>VEK280 YOLOv7 Live Detection</title>
<style>
body { margin:0; padding:16px; background:#101418; color:#e8eef2;
       font-family:Arial,sans-serif; text-align:center; }
h2 { margin:8px 0 14px; }
img { display:block; width:100%; max-width:1100px; height:auto;
      margin:0 auto; border:1px solid #46515b; }
.note { color:#aab7c2; font-size:13px; }
</style>
</head>
<body>
<h2>VEK280 YOLOv7 Live Detection</h2>
<img src="/stream.mjpg" alt="Waiting for camera stream">
<p class="note">Live NPU detections · Refresh this page to reconnect</p>
</body>
</html>
"""


class BrowserStreamHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path == "/" or self.path == "/index.html":
            body = BROWSER_PAGE.encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(body)
            return

        if self.path != "/stream.mjpg":
            self.send_error(404)
            return

        self.send_response(200)
        self.send_header(
            "Content-Type",
            "multipart/x-mixed-replace; boundary=frame"
        )
        self.send_header("Cache-Control", "no-cache, no-store, must-revalidate")
        self.send_header("Pragma", "no-cache")
        self.send_header("Connection", "close")
        self.end_headers()

        last_jpeg = None
        try:
            while STREAM_STATE["running"]:
                with STREAM_LOCK:
                    jpeg = STREAM_STATE["jpeg"]

                if jpeg is None or jpeg is last_jpeg:
                    time.sleep(0.01)
                    continue

                self.wfile.write(b"--frame\r\n")
                self.wfile.write(b"Content-Type: image/jpeg\\r\\n")
                self.wfile.write(
                    f"Content-Length: {len(jpeg)}\r\n\r\n".encode("ascii")
                )
                self.wfile.write(jpeg)
                self.wfile.write(b"\\r\\n")
                last_jpeg = jpeg
        except (BrokenPipeError, ConnectionResetError, OSError):
            pass

    def log_message(self, fmt, *args):
        pass


def main():
    global PAD

    ap = argparse.ArgumentParser()
    ap.add_argument("--device", default="/dev/video0")
    ap.add_argument("--width", type=int, default=640)
    ap.add_argument("--height", type=int, default=480)
    ap.add_argument("--seconds", type=float, default=0)
    ap.add_argument("--conf", type=float, default=0.25)
    ap.add_argument("--headless", action="store_true")
    ap.add_argument("--no-labels", action="store_true")
    ap.add_argument("--http-host", default="0.0.0.0",
                    help="browser stream bind address (default: all interfaces)")
    ap.add_argument("--http-port", type=int, default=8080,
                    help="browser stream TCP port (default: 8080)")
    ap.add_argument("--no-browser", action="store_true",
                    help="disable browser MJPEG streaming")
    a = ap.parse_args()

    cv2.setNumThreads(1)

    print("Opening camera:", a.device)

    cap = cv2.VideoCapture(a.device, cv2.CAP_V4L2)
    if not cap.isOpened():
        sys.exit("ERROR: camera could not be opened")

    cap.set(
        cv2.CAP_PROP_FOURCC,
        cv2.VideoWriter_fourcc(*"MJPG")
    )
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, a.width)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, a.height)
    cap.set(cv2.CAP_PROP_FPS, 30)

    ok, test_frame = cap.read()
    if not ok or test_frame is None:
        cap.release()
        sys.exit("ERROR: camera opened but did not deliver a frame")

    print(
        f"Camera active: {test_frame.shape[1]}x{test_frame.shape[0]}"
    )
    print(
        "Camera FOURCC:",
        int(cap.get(cv2.CAP_PROP_FOURCC)),
        "reported FPS:",
        cap.get(cv2.CAP_PROP_FPS)
    )

    print("\nLoading native INT8 NPU-only VART runner...")
    import vart_ml

    t = time.perf_counter()
    runner = vart_ml.VartMLRunner(
        SNAP,
        network_name="wrp_network",
        npu_only=True
    )
    runner.set_input_native()
    runner.set_output_native()

    print(f"Model load: {time.perf_counter() - t:.2f}s")

    lut4, PAD = make_input_buffers()
    input_array = np.empty((1, H, W, 4), np.uint8)
    rgba = np.empty((H, W, 4), np.uint8)

    input_array[:] = PAD
    x0 = input_array.view(np.int8)

    print("Warming up NPU...")
    t = time.perf_counter()
    warm = None
    for _ in range(6):
        warm = runner.run(x0)

    print(f"Warm-up: {time.perf_counter() - t:.2f}s")
    print("Output tensors:")
    for i, o in enumerate(warm):
        print(f"  Head {i}: shape={o.shape}, dtype={o.dtype}")

    # Latest-frame camera buffer.
    lock = threading.Lock()
    stop_capture = threading.Event()
    latest = {"seq": 0, "time": 0.0, "frame": None}

    def capture_worker():
        while not stop_capture.is_set():
            ok, frame = cap.read()
            if not ok or frame is None:
                time.sleep(0.005)
                continue

            stamp = time.perf_counter()
            with lock:
                latest["seq"] += 1
                latest["time"] = stamp
                latest["frame"] = frame

    capture_thread = threading.Thread(
        target=capture_worker,
        daemon=True
    )
    capture_thread.start()

    httpd = None
    http_thread = None
    if not a.no_browser:
        try:
            httpd = ThreadingHTTPServer(
                (a.http_host, a.http_port), BrowserStreamHandler
            )
            httpd.daemon_threads = True
            http_thread = threading.Thread(
                target=httpd.serve_forever, daemon=True
            )
            http_thread.start()
            print("\nBrowser live detection: http://192.168.1.25:%d/" % a.http_port)
            print("MJPEG stream endpoint:   http://192.168.1.25:%d/stream.mjpg" % a.http_port)
        except OSError as exc:
            stop_capture.set()
            cap.release()
            raise SystemExit(
                f"ERROR: could not start browser server on "
                f"{a.http_host}:{a.http_port}: {exc}"
            )

    show = (
        not a.headless
        and bool(os.environ.get("DISPLAY") or os.environ.get("WAYLAND_DISPLAY"))
    )

    if show:
        print("Live display enabled. Press q to quit.")
    else:
        print("Headless mode: reporting performance only.")

    print("Starting live inference. Ctrl+C to stop.\n")

    start = time.perf_counter()
    report_time = start
    last_seq = 0

    processed = 0
    captured_at_start = 0
    captured_previous = 0

    infer_ms = 0.0
    e2e_ms = 0.0
    detections_count = 0
    ema_fps = None

    try:
        while True:
            if a.seconds and time.perf_counter() - start >= a.seconds:
                break

            with lock:
                seq = latest["seq"]
                frame_time = latest["time"]
                frame = latest["frame"]

            if frame is None or seq == last_seq:
                time.sleep(0.001)
                continue

            last_seq = seq
            t0 = time.perf_counter()

            scale, dx, dy = preprocess(
                frame, input_array, lut4, rgba
            )

            t1 = time.perf_counter()
            outputs = runner.run(input_array.view(np.int8))
            t2 = time.perf_counter()

            detections = postprocess(
                outputs,
                scale,
                dx,
                dy,
                frame.shape,
                a.conf
            )

            t3 = time.perf_counter()

            infer_ms = (t2 - t1) * 1000.0
            e2e_ms = (t3 - frame_time) * 1000.0

            processed += 1
            detections_count += len(detections)

            inst_fps = 1.0 / max(t3 - t0, 1e-9)
            ema_fps = (
                inst_fps if ema_fps is None
                else 0.9 * ema_fps + 0.1 * inst_fps
            )

            if show or not a.no_browser:
                display_frame = frame.copy()

                if not a.no_labels:
                    draw(display_frame, detections)
                else:
                    for x1, y1, x2, y2, score, cls in detections:
                        cv2.rectangle(
                            display_frame,
                            (int(x1), int(y1)),
                            (int(x2), int(y2)),
                            (0, 255, 0),
                            2
                        )

                cv2.putText(
                    display_frame,
                    f"Processed FPS: {ema_fps:.1f}",
                    (8, 22),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.6,
                    (0, 255, 255),
                    2
                )
                cv2.putText(
                    display_frame,
                    f"NPU: {infer_ms:.1f} ms  Dets: {len(detections)}",
                    (8, 48),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.55,
                    (0, 255, 255),
                    2
                )

                if not a.no_browser:
                    ok_jpg, encoded = cv2.imencode(
                        ".jpg", display_frame,
                        [cv2.IMWRITE_JPEG_QUALITY, 80]
                    )
                    if ok_jpg:
                        with STREAM_LOCK:
                            STREAM_STATE["jpeg"] = encoded.tobytes()

                if show:
                    try:
                        cv2.imshow("VEK280 YOLOv7 Native INT8", display_frame)
                        if cv2.waitKey(1) & 0xFF == ord("q"):
                            break
                    except cv2.error:
                        show = False
                        print("Display unavailable; browser/headless mode continues.")

            now = time.perf_counter()
            if now - report_time >= 2.0:
                elapsed = now - start
                with lock:
                    captured = latest["seq"]

                capture_fps = (
                    (captured - captured_previous)
                    / max(now - report_time, 1e-9)
                )
                captured_previous = captured

                print(
                    f"Captured FPS: {capture_fps:.1f} | "
                    f"Processed FPS: {processed / elapsed:.2f} | "
                    f"NPU: {infer_ms:.1f} ms | "
                    f"Camera-to-result: {e2e_ms:.1f} ms | "
                    f"Detections: {len(detections)} | "
                    f"Frames processed: {processed}"
                )
                report_time = now

    except KeyboardInterrupt:
        print("\nInterrupted by user.")

    finally:
        STREAM_STATE["running"] = False
        if httpd is not None:
            httpd.shutdown()
            httpd.server_close()
        stop_capture.set()
        cap.release()
        capture_thread.join(timeout=2)

        if show:
            cv2.destroyAllWindows()

        elapsed = time.perf_counter() - start

        print("\n========== WEBCAM SUMMARY ==========")
        print(f"Duration:              {elapsed:.2f} s")
        print(f"Frames processed:      {processed}")
        print(f"Average processed FPS: {processed / elapsed:.2f}" if elapsed else "Average processed FPS: N/A")
        print(f"Last NPU latency:      {infer_ms:.2f} ms")
        print(f"Last camera-result:    {e2e_ms:.2f} ms")
        print(f"Average detections:    {detections_count / processed:.2f}" if processed else "Average detections: N/A")
        print("====================================")


if __name__ == "__main__":
    main()
