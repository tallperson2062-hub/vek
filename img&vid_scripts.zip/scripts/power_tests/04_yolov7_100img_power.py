#!/usr/bin/env python3
import os
import sys
import time
import signal
import subprocess
from pathlib import Path

BASE = Path("/root/vek280_yolov7_profile")
POWER_SOURCE = BASE / "vek280_idle_power.py"
POWER_SCRIPT = BASE / "vek280_yolov7_active_power.py"
INFERENCE_SCRIPT = BASE / "03_e2e_system_profile.py"

OUT = BASE / "results" / "yolov7_100img_power"
OUT.mkdir(parents=True, exist_ok=True)

POWER_LOG = OUT / "power_monitor.log"
INFERENCE_LOG = OUT / "inference.log"
POWER_CSV = OUT / "power_rails.csv"
POWER_JSON = OUT / "power_summary.json"

# Copy the verified power monitor without changing its sensor map.
source = POWER_SOURCE.read_text()
source = source.replace(
    "sum of 19 INA226-monitored rails",
    "sum of 20 INA226-monitored rails"
)
source = source.replace(
    "TOTAL (19 mon. rails)",
    "TOTAL (20 mon. rails)"
)
source = source.replace(
    "19 INA226-monitored rails",
    "20 INA226-monitored rails"
)
POWER_SCRIPT.write_text(source)
POWER_SCRIPT.chmod(0o755)

if not INFERENCE_SCRIPT.is_file():
    sys.exit(f"Missing inference script: {INFERENCE_SCRIPT}")

if not (BASE / "assets" / "snapshot.VE2802_NPU_IP_O00_A304_M3.yolov7.TF").exists():
    sys.exit("YOLOv7 snapshot not found.")

power_log = open(POWER_LOG, "w")

print("Starting 20-rail INA226 power monitor...", flush=True)

monitor = subprocess.Popen(
    [
        sys.executable, str(POWER_SCRIPT),
        "--duration", "3600",
        "--interval", "1",
        "--csv", str(POWER_CSV),
        "--json", str(POWER_JSON),
        "--scroll",
    ],
    stdout=None,
    stderr=None,
)

try:
    time.sleep(2)

    if monitor.poll() is not None:
        raise RuntimeError(
            f"Power monitor exited early with code {monitor.returncode}. "
            f"Check {POWER_LOG}"
        )

    print("Power monitor active.", flush=True)
    print("Starting YOLOv7 inference on first 100 images...", flush=True)

    with open(INFERENCE_LOG, "w") as inference_log:
        result = subprocess.run(
            [
                sys.executable, str(INFERENCE_SCRIPT),
                "--limit", "100",
                "--npu-iters", "1",
                "--save-annotated", "0",
                "--out", str(OUT / "inference_results"),
            ],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
        )

        inference_log.write(result.stdout)
        inference_log.flush()
        print(result.stdout, end="", flush=True)

    if result.returncode != 0:
        print(f"Inference exited with code {result.returncode}.", flush=True)

finally:
    if monitor.poll() is None:
        print("\nStopping power monitor and collecting summary...", flush=True)
        monitor.send_signal(signal.SIGINT)
        try:
            monitor.wait(timeout=20)
        except subprocess.TimeoutExpired:
            monitor.terminate()
            monitor.wait(timeout=5)

    power_log.close()

print("\n========== POWER MEASUREMENT FILES ==========")
print("Power CSV :", POWER_CSV)
print("Power JSON:", POWER_JSON)
print("Power log :", POWER_LOG)
print("Inference :", INFERENCE_LOG)

if POWER_JSON.exists():
    print("\nPower measurement completed.")
else:
    print("\nWARNING: No power summary JSON was produced.")
    print("Inspect:", POWER_LOG)
